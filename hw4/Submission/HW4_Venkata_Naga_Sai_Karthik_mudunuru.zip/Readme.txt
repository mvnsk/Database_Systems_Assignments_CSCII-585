Q1) The equation is 
  
class =

     -0.108  * CRIM +
      0.0464 * ZN +
      0.0206 * INDUS +
      2.6867 * CHAS=1 +
    -17.7666 * NOX +
      3.8099 * RM +
      0.0007 * AGE +
     -1.4756 * DIS +
      0.306  * RAD +
     -0.0123 * TAX +
     -0.9527 * PTRATIO +
      0.0093 * B +
     -0.5248 * LSTAT +
     36.4595

There are 14 terms in the equation, including the constant term. I've opted for "No attribute selection" feature. Because of this, all the 13 variables
are considered for the linear regression i.e each of the 13 variables(features) is considered in the prediction of class/Medv. And the constant (intercept
) term is included in a line equation. Hence, in total,there are 14 terms.


Q2) Lowest RMSE is 2.5856.


Q3) Linear regression equation is
num_rings =-0.8249 * sex=I + 0.0577 * sex=M +(-0.4583) * length + 11.0751 * diameter + 10.7615 * height + 8.9754 * whole_weight +
(-19.7869) * shucked_weight + (-10.5818) * viscera_weight + 8.7418 * shell_weight + 3.8946
 
Q5) The following number of clusters are present in each cluster:
Cluster 0:1388
Cluster 1:499	
Cluster 2:448	
Cluster 3:22	
Cluster 4:172
Cluster 5:1648


Q6)num_rings= -11.933 * length + 25.766 * diameter + 20.358 * height + 2.836